Hooks.on('ready', () => {
	CONFIG.DND5E.weaponProperties['iosan'] = 'Iosan';
	CONFIG.DND5E.weaponTypes['steamjack'] = 'Steamjack';
	CONFIG.DND5E.armorTypes['steamjack'] = 'Steamjack';
});